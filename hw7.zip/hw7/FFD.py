import numpy as np
from collections import defaultdict

def ffd(im_height:int,im_width:int, m:int, n:int, shift_dict:dict) -> np.array:
    #第一步:定义用于计算权重的B样条核函数
    def beta(a,index):
        if index == -1: return (1-a)**3 / 6
        if index == 0:  return (3*a**3 - 6 * a**2 + 4)/6
        if index == 1:  return (-3*a**3 + 3*a**2 + 3*a +1)/6
        if index == 2:  return a**3/6

    #第二步:构建用于存储所有控制点位移的defaultdict
    def return_no_shift():
        return np.zeros(2)
    shift = defaultdict(return_no_shift)
    for item in shift_dict.items():
        i,j = item[0]
        delta_x,delta_y = item[1]
        shift[(i,j)] = np.array([delta_x,delta_y])

    #第三步:计算每个像素点在形变后的坐标
    lx = im_height/m
    ly = im_width/n
    shifted_index = np.zeros((im_height,im_width,2))
    for x in range(im_height):
        for y in range(im_width):
            shifted_index[x,y,:] = np.array([x,y])
    for x in range(im_height):
        dist_1 = (x-0)/lx
        ix = int(dist_1)
        u = dist_1 - ix
        for y in range(im_width):
            dist_2 = (y-0)/ly
            iy = int(dist_2)
            v = dist_2 - iy
            for p in [-1,0,1,2]:
                for q in [-1,0,1,2]:
                    shifted_index[x,y,:] += shift[(ix+p,iy+q)] * beta(u,p) * beta(v,q)
    return shifted_index