#基于highboost的方法进行锐化
import numpy as np
from numba import jit
from PIL import Image
import os

@jit
def sharpen_highboost(pixels, sigma, k):
    kernelSize = 1 + 2 * int(3 * sigma)
    Kernal = np.zeros((kernelSize, kernelSize))
    m = kernelSize // 2

    for i in range(kernelSize):
        for j in range(kernelSize):
            Kernal[i, j] = np.exp(-((i - m) ** 2 + (j - m) ** 2) / (2 * sigma ** 2))

    Kernal = Kernal / np.sum(Kernal)

    P = np.ones((pixels.shape[0] + 2 * m, pixels.shape[1] + 2 * m))
    P = P * 127
    P[m:P.shape[0] - m, m:P.shape[1] - m] = pixels

    blurred = np.zeros_like(P, dtype=np.float64)

    for i in range(m, P.shape[0] - m):
        for j in range(m, P.shape[1] - m):
            blurred[i, j] = np.sum(P[i - m:i + m + 1, j - m:j + m + 1] * Kernal)

    blurred = blurred[m:blurred.shape[0] - m, m:blurred.shape[1] - m]

    # 计算unsharp mask
    unsharp_mask = pixels.astype(np.float64) - blurred

    # 归一化
    if np.max(np.abs(unsharp_mask)) > 0:
        unsharp_mask = unsharp_mask / np.max(np.abs(unsharp_mask))

    # 锐化
    result = pixels.astype(np.float64) + k * unsharp_mask

    result = np.clip(result, 0, 255)

    return result.astype(np.float64)

def main():
    myPicture = '锐化测试.png'
    im_raw = Image.open(myPicture)
    im = im_raw.convert('L')
    pixels = np.array(im)

    result_dir = '锐化结果'
    if not os.path.exists(result_dir):
        os.makedirs(result_dir)

    sigma = 1
    for k in [25,50,75,100]:
        pixels2 = sharpen_highboost(pixels, sigma, k)
        pixels2 = pixels2.astype(np.uint8)
        new_im = Image.fromarray(pixels2)
        new_im.save(os.path.join(result_dir, f'sharpen_highboost_sigma={sigma}_k={k}.png'))

if __name__ == '__main__':
    main()