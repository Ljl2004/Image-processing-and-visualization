import numpy as np
from PIL import Image
from math import exp


def logRescale(M:np.array) -> np.array:
    """先取模得到频谱，然后取对数，并映射到[0,255]区间，将映射后的频谱返回"""
    # m,n = M.shape
    M = np.abs(M) # 取模得到频谱
    M = np.log(M + 1) # 取对数
    largest = np.max(M)
    least = np.min(M)
    M = 255 * (M - least)/(largest - least)
    M = np.uint8(M) # 无符号整数可以表示0~255
    return M


def rescale(M:np.array) -> np.array:
    largest = np.max(M)
    least = np.min(M)
    M = 255 * (M - least)/(largest - least)
    M = np.uint8(M)
    return M


def smooth(pixels: np.array, sigam:float = 10) -> (np.array, np.array, np.array):
    m,n = pixels.shape
    P = np.zeros((2*m, 2*n))
    P[0:m, 0:n] = pixels

    S = np.ones((2*m, 2*n))
    for x in range(1,S.shape[0],2):
        S[x,:] *= -1
    for y in range(1,S.shape[1],2):
        S[:,y] *= -1
    P = P * S

    F = np.fft.fft2(P)
    H = np.empty(F.shape)
    center = np.array([H.shape[0]//2, H.shape[1]//2])
    for x in range(H.shape[0]):
        for y in range(H.shape[1]):
            D2 = (x-center[0])**2 + (y-center[1])**2
            H[x,y] = exp(-D2/(2*sigam**2)) 
    G = F*H

    g = np.fft.ifft2(G).real
    g = g*S
    g = g[0:m, 0:n]
    for x in range(g.shape[0]):
        for y in range(g.shape[1]):
            if g[x,y] > 255:
                g[x,y] = 255
            elif g[x,y] < 0:
                g[x,y] = 0

    return F, G, g

def main():
    myPicture = 'test.jpeg'
    im_raw = Image.open(myPicture)
    im = im_raw.convert('L')
    pixels = np.array(im) 
    sigmas = [25,50,75,100]

    for sigma in sigmas:
        orig_freq, filter_freq, smooth_pixels = smooth(pixels,sigma)

        orig_freq = logRescale(orig_freq)
        filter_freq = logRescale(filter_freq)

        smooth_pixels = rescale(smooth_pixels)

        freq_im = Image.fromarray(orig_freq)
        filtered_freq_im = Image.fromarray(filter_freq)
        smooth_im = Image.fromarray(smooth_pixels)

        freq_im.save('smooth/'+'sigma='+str(sigma)+' frequency'+'.png')
        filtered_freq_im.save('smooth/'+'sigma='+str(sigma)+' filtered frequency'+'.png')
        smooth_im.save('smooth/'+'sigma='+str(sigma)+' filtered figure'+'.png')

if __name__ == '__main__':
    main()