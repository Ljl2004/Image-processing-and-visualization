import cv2
import numpy as np

filename = "image.jpg"
winname = "figure"
img = cv2.imread(filename)


def addSaltPepperNoise():
    # 指定信噪比
    SNR = 0.99
    # 获取总共像素个数
    size = img.size
    # 因为信噪比是 SNR ，所以噪声占据百分之10，所以需要对这百分之10加噪声
    noiseSize = int(size * (1 - SNR))
    # 对这些点加噪声
    for k in range(0, noiseSize):
        # 随机获取 某个点
        xi = int(np.random.uniform(0, img.shape[1]))
        xj = int(np.random.uniform(0, img.shape[0]))

        # 随机决定是椒噪声（黑色）还是盐噪声（白色）
        # 生成0或1的随机整数，0代表椒噪声，1代表盐噪声
        noise_type = np.random.randint(0, 2)

        # 增加噪声
        if img.ndim == 2:  # 灰度图像
            if noise_type == 0:  # 椒噪声（黑色）
                img[xj, xi] = 0
            else:  # 盐噪声（白色）
                img[xj, xi] = 255
        elif img.ndim == 3:  # 彩色图像
            if noise_type == 0:  # 椒噪声（黑色）
                img[xj, xi] = [0, 0, 0]
            else:  # 盐噪声（白色）
                img[xj, xi] = [255, 255, 255]

    cv2.imshow(winname, img)
    cv2.waitKey(0)

    # 保存图像
    output_filename = "salt_pepper_noise_image.jpg"
    cv2.imwrite(output_filename, img)
    print(f"椒盐噪声图像已保存为: {output_filename}")


def main():
    addSaltPepperNoise()


if __name__ == '__main__':
    main()