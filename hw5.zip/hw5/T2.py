import numpy as np
from PIL import Image
from numba import njit


def truncate(M: np.array) -> np.array:
    M = np.clip(M, 0, 255)  # 截断
    M = np.uint8(M)
    return M


def rescale(M: np.array) -> np.array:
    largest = np.max(M)
    least = np.min(M)
    M = 255 * (M - least) / (largest - least)
    M = np.uint8(M)
    return M


def logRescale(M: np.array) -> np.array:
    M = np.abs(M)
    M = np.log(M + 1)
    largest = np.max(M)
    least = np.min(M)
    M = 255 * (M - least) / (largest - least)
    M = np.uint8(M)
    return M


def get_freq_spectrum(pixels: np.array):
    m, n = pixels.shape
    P = np.zeros((2 * m, 2 * n))
    P[0:m, 0:n] = pixels
    F = np.fft.fft2(P)
    F = np.fft.fftshift(F)
    return F


@njit
def best_notch_filter(pixels, noise, patchSize: int):
    X, Y = pixels.shape
    half = patchSize // 2
    w = np.zeros((X, Y))
    for i in range(half, X - half):
        for j in range(half, Y - half):
            g = pixels[i - half:i + half + 1, j - half:j + half + 1]
            n = noise[i - half:i + half + 1, j - half:j + half + 1]
            gn = g * n
            n2 = n * n
            n_mean = np.average(n)
            n2_mean = np.average(n2)
            gn_mean = np.average(gn)
            g_mean = np.average(g)
            w[i, j] = (gn_mean - g_mean * n_mean) / (n2_mean - n_mean + 0.001)
    return pixels - w * noise


def main():
    im_raw = Image.open("作业四 图像.PNG")
    im = im_raw.convert('L')
    pixels = np.array(im)

    F = get_freq_spectrum(pixels)
    F_log = logRescale(F)
    im_ori_freq_spectrum = Image.fromarray(F_log)
    im_ori_freq_spectrum.save('T2_result/' + '原图频谱.png')

    m, n = pixels.shape
    H = np.ones((2 * m, 2 * n))
    H[m - 90:m + 90, :] = 0
    H[:, n - 90:n + 90] = 0

    H_rescale = rescale(H)
    im_H = Image.fromarray(H_rescale)
    im_H.save('T2_result/' + '噪声滤波器.png')

    noise_freq = F * H
    noise_freq_log = logRescale(noise_freq)
    im_noise_freq_log = Image.fromarray(noise_freq_log)
    im_noise_freq_log.save('T2_result/' + '噪声频域图像.png')

    noise_freq = np.fft.ifftshift(noise_freq)
    noise = np.fft.ifft2(noise_freq).real
    noise = noise[0:m, 0:n]

    # 修复这一行：使用rescale函数处理noise
    noise_rescaled = rescale(noise)  # 添加这一行
    im_noise = Image.fromarray(noise_rescaled)  # 修改这一行
    im_noise.save('T2_result/' + "噪声图像.png")

    for patchSize in [3, 5, 7, 9, 11, 13]:
        filtered_figure = best_notch_filter(pixels, noise, patchSize)
        filtered_figure = truncate(filtered_figure)
        im = Image.fromarray(filtered_figure)
        im.save('T2_result/' + '滤波后图像 patchSize=' + str(patchSize) + '.png')


if __name__ == '__main__':
    main()