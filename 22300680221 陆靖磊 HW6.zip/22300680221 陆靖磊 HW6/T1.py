import numpy as np
import random
from PIL import Image
import os
import cv2


def kmeans_segmentation(pixels, k=2):
    """
    K-means图像分割算法
    para: pixels - 灰度图像矩阵
    para: k - 聚类数量
    return: 分割后的图像矩阵
    """
    height, width = pixels.shape

    # 将图像展平为一维数组
    data = pixels.flatten()

    # 随机初始化k个中心点
    centers = np.random.randint(0, 256, size=k)

    # 迭代次数
    max_iterations = 100

    for _ in range(max_iterations):
        # 步骤1: 将每个像素分配到最近的中心
        distances = np.abs(data[:, np.newaxis] - centers)
        labels = np.argmin(distances, axis=1)

        # 步骤2: 更新中心点
        new_centers = np.zeros(k)
        for i in range(k):
            cluster_pixels = data[labels == i]
            if len(cluster_pixels) > 0:
                new_centers[i] = np.mean(cluster_pixels)
            else:
                # 如果某个聚类没有点，重新随机初始化
                new_centers[i] = np.random.randint(0, 256)

        # 检查是否收敛
        if np.max(np.abs(centers - new_centers)) < 1:
            break

        centers = new_centers

    # 将标签映射回图像
    segmented = labels.reshape((height, width))

    return segmented


def otsu_thresholding(pixels):
    """
    OTSU阈值算法（使用OpenCV实现）
    return: 二值化图像
    """
    _, binary_img = cv2.threshold(pixels, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return binary_img


def visualize_segmentation(segmented, k):
    """
    可视化分割结果
    para: segmented - 分割后的图像矩阵
    para: k - 聚类数量
    return: 可视化图像
    """
    # 生成k种颜色
    colors = []
    for i in range(k):
        r = int(255 * (i / (k - 1)) if k > 1 else 0)
        g = int(255 * ((k - i - 1) / (k - 1)) if k > 1 else 0)
        b = int(255 * (0.5 + 0.5 * (i % 2)) if k > 1 else 0)
        colors.append((r, g, b))

    # 创建彩色图像
    height, width = segmented.shape
    color_img = np.zeros((height, width, 3), dtype=np.uint8)

    for i in range(height):
        for j in range(width):
            color_img[i, j] = colors[segmented[i, j]]

    return color_img


def main():
    # 创建结果目录
    os.makedirs('T1_result', exist_ok=True)

    # 图像路径（你的椒盐噪声图片）
    noisy_image_path = 'salt_pepper_noise_image.jpg'

    # 读取噪声图像
    print(f"读取噪声图像: {noisy_image_path}")
    noisy_img = Image.open(noisy_image_path).convert('L')
    noisy_pixels = np.array(noisy_img)

    print(f"图像尺寸: {noisy_pixels.shape}")
    print(f"灰度范围: {noisy_pixels.min()} ~ {noisy_pixels.max()}")

    # (1) OTSU二值化
    print("\n1. 进行OTSU二值化...")
    otsu_result = otsu_thresholding(noisy_pixels)
    Image.fromarray(otsu_result).save('T1_result/otsu_binary.png')
    print("   结果保存为: T1_result/otsu_binary.png")

    # (2) K-means二类分割
    print("\n2. 进行K-means二类分割...")
    kmeans_binary = kmeans_segmentation(noisy_pixels, k=2)
    kmeans_binary_vis = visualize_segmentation(kmeans_binary, k=2)
    Image.fromarray(kmeans_binary_vis).save('T1_result/kmeans_k2.png')
    print("   结果保存为: T1_result/kmeans_k2.png")

    # (3) K-means多类分割
    print("\n3. 进行K-means多类分割...")
    for k in [3, 4, 5, 6]:
        print(f"   K={k}分割中...")
        kmeans_result = kmeans_segmentation(noisy_pixels, k=k)
        kmeans_result_vis = visualize_segmentation(kmeans_result, k=k)
        Image.fromarray(kmeans_result_vis).save(f'T1_result/kmeans_k{k}.png')
        print(f"   结果保存为: T1_result/kmeans_k{k}.png")

    print("\n所有处理完成!")
    print("OTSU和K-means(2类)的结果对比在T1_result文件夹中")
    print("K-means多类分割结果也保存在同一文件夹")


if __name__ == '__main__':
    main()