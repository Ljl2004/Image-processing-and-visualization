import numpy as np 
from PIL import Image
from math import pi

def truncate(M:np.array) -> np.array:
    """将超出[0,255]区间的灰度值进行截断，并返回uint8类型"""
    M = np.clip(M,0,255) # 截断
    M = np.uint8(M) # 无符号整数可以表示0~255
    return M

#白噪声生成
def generator_w(m: int, n: int, rv_type: str = 'uniform') -> np.array:
    const = 1
    noise_spectrum = const * np.ones((m, n))
    if rv_type == 'uniform':
        noise_phase = 1j * np.random.uniform(0, 2 * pi, (m, n))
        noise_phase = np.exp(noise_phase)
    elif rv_type == 'Gauss':
        noise_phase = 1j * np.random.normal(0, pi, (m, n))
        noise_phase = np.exp(noise_phase)
    noise = np.fft.ifft2(noise_spectrum * noise_phase).real
    noise = noise / np.max(np.abs(noise))
    return noise

#瑞丽噪声生成
def generator_r(m:int, n:int, a:float = -1, b:float = 10) -> np.array:
    noise = a + np.random.rayleigh(scale=b,size=(m,n))
    noise = noise/np.max(np.abs(noise))
    return noise

def main():
    for fileName in ['大脑图像.png','心脏图像.png']:
        im_raw = Image.open(fileName)
        im = im_raw.convert('L')
        pixels = np.array(im)
        m = pixels.shape[0]
        n = pixels.shape[1]
        for c in [50,100,150]:
            pixels_w_u_noise = pixels + c*generator_w(m,n,rv_type='uniform')
            im1 = Image.fromarray(truncate(pixels_w_u_noise))
            im1.save('T1_result/'+fileName[0:4]+' c='+str(c)+' uniform white noise.png')
            pixels_w_g_noise = pixels + c*generator_w(m,n,rv_type='Gauss')
            im2 = Image.fromarray(truncate(pixels_w_g_noise))
            im2.save('T1_result/'+fileName[0:4]+' c='+str(c)+' Gauss white noise.png')
            pixels_r_noise = pixels + c*generator_r(m,n)
            im3 = Image.fromarray(truncate(pixels_r_noise))
            im3.save('T1_result/'+fileName[0:4]+' c='+str(c)+' Rayleigh noise.png')

if __name__ == '__main__':
    main()