import numpy as np
from PIL import Image
from math import pi

def logRescale(M:np.array) -> np.array:
    """先取模得到频谱，然后取对数，并映射到[0,255]区间，将映射后的频谱返回"""
    M = np.abs(M)
    M = np.log(M + 1)
    largest = np.max(M)
    least = np.min(M)
    M = 255 * (M - least)/(largest - least)
    M = np.uint8(M)
    return M

def rescale(M:np.array) -> np.array:
    """映射到[0,255]区间"""
    # m,n = M.shape
    largest = np.max(M)
    least = np.min(M)
    M = 255 * (M - least)/(largest - least)
    M = np.uint8(M)
    return M

# @jit
def LaplacianFilter(pixels: np.array) -> (np.array, np.array, np.array):
    """
    Laplacian sharpen filter in frequency
    :param: pixels are the indensity of all the pixels in your image
    :return: three arrays: the original frequency F, the filtered frequency H, and the Laplacian g
    """
    m,n = pixels.shape
    P = np.zeros((2*m, 2*n))
    P[0:m, 0:n] = pixels

    S = np.ones((2*m, 2*n))
    for x in range(1,S.shape[0],2):
        S[x,:] *= -1
    for y in range(1,S.shape[1],2):
        S[:,y] *= -1
    P = P * S

    F = np.fft.fft2(P)
    H = np.zeros(F.shape)
    center = np.array([H.shape[0]//2, H.shape[1]//2])
    for x in range(H.shape[0]):
        for y in range(H.shape[1]):
            D2 = (x-center[0])**2 + (y-center[1])**2
            H[x,y] = -4 * pi**2 * D2
    G = F*H

    g = np.fft.ifft2(G).real
    g = g[0:m, 0:n]
    gMax = np.max(g)
    g = g/gMax

    return F, G, g

def main():
    myPicture = 'test.jpeg'
    im_raw = Image.open(myPicture)
    im = im_raw.convert('L')
    pixels = np.array(im) 

    # 锐化操作
    orig_freq, filter_freq, lap = LaplacianFilter(pixels)

    orig_freq = logRescale(orig_freq)
    filter_freq = logRescale(filter_freq)

    freq_im = Image.fromarray(orig_freq)
    filtered_freq_im = Image.fromarray(filter_freq)

    freq_im.save('sharpen/'+'frequency'+'.png')
    filtered_freq_im.save('sharpen/'+'filtered frequency'+'.png')

    lap_trans = logRescale(lap)
    lap_im = Image.fromarray(lap_trans)
    lap_im.save('sharpen/'+'laplace.png')

    for c in [-5,-10,-15,-20,-50]:
        sharpen_pixels = pixels + c*lap

        sharpen_pixels = np.uint8(sharpen_pixels)
        for i in range(sharpen_pixels.shape[0]):
            for j in range(sharpen_pixels.shape[1]):
                p = sharpen_pixels[i,j]
                if p > 255:
                    sharpen_pixels[i,j] = 255
                elif p < 0:
                    sharpen_pixels[i,j] = 0

        sharpen_im = Image.fromarray(sharpen_pixels)
        sharpen_im.save('sharpen/'+'c='+str(c)+'.png')

if __name__ == '__main__':
    main()