import numpy as np
from PIL import Image
from math import exp
import os  # 新增导入

def logRescale(M: np.array) -> np.array:
    """先取模得到频谱，然后取对数，并映射到[0,255]区间，将映射后的频谱返回"""
    # m,n = M.shape
    M = np.abs(M)
    M = np.log(M + 1)
    largest = np.max(M)
    least = np.min(M)
    M = 255 * (M - least) / (largest - least)
    M = np.uint8(M)
    return M


# @jit
def rescale(M: np.array) -> np.array:
    """映射到[0,255]区间"""
    # m,n = M.shape
    largest = np.max(M)
    least = np.min(M)
    M = 255 * (M - least) / (largest - least)
    M = np.uint8(M)
    return M


# @jit
def removeNoise(pixels: np.array) -> (np.array, np.array, np.array):
    """
    remove noise from the target noisy picture provided by Prof. Zhuang
    :param: pixels are the indensity of all the pixels in the noise image
    :return: three arrays: the original frequency F, the filtered frequency G, and the filtered figure
    """
    m, n = pixels.shape
    P = np.zeros((2 * m, 2 * n))
    P[0:m, 0:n] = pixels

    S = np.ones((2 * m, 2 * n))
    for x in range(1, S.shape[0], 2):
        S[x, :] *= -1
    for y in range(1, S.shape[1], 2):
        S[:, y] *= -1
    P = P * S

    F = np.fft.fft2(P)

    H = np.zeros(F.shape)
    H = np.empty(F.shape)
    center = np.array([H.shape[0] // 2, H.shape[1] // 2])
    sigma = 28
    for x in range(H.shape[0]):
        for y in range(H.shape[1]):
            H[x, y] = exp(-(x - center[0]) ** 2 / (2 * sigma ** 2)) + exp(-(y - center[1]) ** 2 / (2 * sigma ** 2))

    G = F * H

    g = np.fft.ifft2(G).real
    g = g[0:m, 0:n]
    for x in range(g.shape[0]):
        for y in range(g.shape[1]):
            if g[x, y] > 255:
                g[x, y] = 255
            elif g[x, y] < 0:
                g[x, y] = 0
    return F, G, g


def main():
    output_dir = 'remove_noise'
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    myPicture = '作业四 图像.PNG'
    im_raw = Image.open(myPicture)
    im = im_raw.convert('L')
    pixels = np.array(im)

    # 去噪
    orig_freq, filter_freq, p = removeNoise(pixels)

    orig_freq = logRescale(orig_freq)
    filter_freq = logRescale(filter_freq)

    freq_im = Image.fromarray(orig_freq)
    filtered_freq_im = Image.fromarray(filter_freq)

    freq_im.save('remove_noise/' + 'frequency' + '.png')
    filtered_freq_im.save('remove_noise/' + 'filtered frequency' + '.png')

    filtered_pixels = rescale(p)
    filtered_im = Image.fromarray(filtered_pixels)

    filtered_im.save('remove_noise/' + 'result.png')

if __name__ == '__main__':
    main()