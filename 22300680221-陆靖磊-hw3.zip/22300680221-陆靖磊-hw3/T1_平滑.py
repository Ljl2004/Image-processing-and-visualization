# 利用局部平均进行平滑处理
import numpy as np
from numba import jit
from PIL import Image
import os


@jit
def smooth_average(pixels, kernelSize):
    m = kernelSize // 2
    P = np.ones((pixels.shape[0] + 2 * m, pixels.shape[1] + 2 * m)) * 127
    P[m:P.shape[0] - m, m:P.shape[1] - m] = pixels

    result = P.copy()

    for i in range(m, P.shape[0] - m):
        for j in range(m, P.shape[1] - m):
            # 计算局部平均值
            result[i, j] = np.sum(P[i - m:i + m + 1, j - m:j + m + 1]) / (kernelSize ** 2)

    return result[m:result.shape[0] - m, m:result.shape[1] - m]


def main():
    myPicture = '平滑测试.jpeg'
    im_raw = Image.open(myPicture)
    im = im_raw.convert('L')
    pixels = np.array(im)

    result_dir = '平滑结果'
    if not os.path.exists(result_dir):
        os.makedirs(result_dir)

    for kernelSize in [5, 10, 15, 20]:
        pixels2 = smooth_average(pixels, kernelSize)
        pixels2 = pixels2.astype(np.uint8)
        new_im = Image.fromarray(pixels2)
        new_im.save(os.path.join(result_dir, f'smooth_average_kernelSize={kernelSize}.png'))

if __name__ == '__main__':
    main()