from math import *
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt


def local_hist(pixels, w):

    # 验证输入
    if w % 2 == 0:
        raise ValueError("w must be an odd number")

    # 确保像素值在正确范围内
    pixels = np.clip(pixels, 0, 255).astype(np.uint8)

    count = 0
    hist = np.zeros((pixels.size, 2 + 256), dtype=np.int32)

    for i in range(pixels.shape[0]):
        up = max(0, i - w // 2)
        down = min(pixels.shape[0] - 1, i + w // 2)
        for j in range(pixels.shape[1]):
            if j == 0:
                hist[count, 0] = i
                hist[count, 1] = j
                rt = min(pixels.shape[1] - 1, j + w // 2)
                for p in range(up, down + 1):
                    for q in range(rt + 1):
                        pixel_val = int(pixels[p, q])
                        hist[count, 2 + pixel_val] += 1
                count += 1
            else:
                hist[count, :] = hist[count - 1, :]
                hist[count, 0] = i
                hist[count, 1] = j
                lf = max(0, j - w // 2)
                rt = min(pixels.shape[1] - 1, j + w // 2)
                if lf == 0:
                    old_col = []
                else:
                    old_col = pixels[up:down + 1, lf - 1]
                if j + w // 2 > rt:
                    new_col = []
                else:
                    new_col = pixels[up:down + 1, rt]

                for item in old_col:
                    item_val = int(item)
                    hist[count, 2 + item_val] -= 1
                for item in new_col:
                    item_val = int(item)
                    hist[count, 2 + item_val] += 1
                count = count + 1
    return hist

def draw_local_histogram(h,bins,w):
    x = h[0]
    y = h[1]
    h = h[2:]
    plt.bar(list(range(bins)), h, color = "#4CAF50")
    t = 'the local histogram centered at (' + str(int(x))+ ',' + str(int(y)) + ')'\
        + ' with patch size=' + str(int(w))
    plt.title(t)
    # plt.show()
    plt.savefig(t+'.jpg')
    pass


def main():
    myPicture = 'test1.jpeg'
    im_raw = Image.open(myPicture)
    im = im_raw.convert('L')
    pixels = np.array(im)
    patch_size = 25
    bins = 256
    hist_list = local_hist(pixels,patch_size)
    # show the first 3, the middle 3, and the last 3 local histogram
    for i in [0, 1,2, pixels.size//2+20, pixels.size//2 + 21,pixels.size//2 + 22, -3,-2, -1]:
        h = hist_list[i,:]
        draw_local_histogram(h,bins,patch_size)


if __name__ == '__main__':
    main()

# 这里将patch size设为了25*25，具体的histogram可参见见文件中的九张local histogram