from FFD import ffd
import numpy as np
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
matplotlib.rc("font",family='YouYuan')
import cv2 as cv
from collections import defaultdict

def interpolation(coord:np.array,ori_img:np.array):
    x , y = coord
    oh, ow = ori_img.shape

    if x < 0 : x = 0
    if x >= oh : x = oh-1
    if y < 0 : y = 0
    if y >= ow : y = ow-1

    min_x , min_y = int(x) , int(y)
    max_x , max_y = min(oh-1,min_x+1) , min(ow-1,min_y+1)

    u , v = x - min_x , y-min_y
    return (1-u)*(1-v)*ori_img[min_x,min_y] + u*(1-v)*ori_img[max_x,min_y] +\
          (1-u)*v*ori_img[min_x,max_y] + u*v*ori_img[max_x,max_y]

def backward_trans(ori_image:np.array, m:int, n:int, shift_dict:dict):
    goal_image = np.zeros(ori_image.shape)
    shifted_index = ffd(goal_image.shape[0],goal_image.shape[1],m,n,shift_dict)
    for i in range(goal_image.shape[0]):
        for j in range(goal_image.shape[1]):
            goal_image[i,j] = interpolation(shifted_index[i,j,:],ori_image)
    
    return goal_image

fig = plt.figure(figsize=(16,12))
ori_img = cv.imread("test.jpg",0)
goal_img = cv.imread("test.jpg",0)
ori_img = cv.resize(ori_img,goal_img.shape)

plt.subplot(121)
plt.imshow(ori_img,cmap=plt.get_cmap("gray"))
plt.title("该图为原始图像，选择控制点")
x = plt.ginput(n=30,timeout=0)
ori_list = np.float32([[int(c[1]),int(c[0])] for c in x])

plt.subplot(122)
plt.imshow(goal_img,cmap=plt.get_cmap("gray"))
plt.title("选择原图的控制点变换后的位置")
y = plt.ginput(n=30,timeout=0)
goal_list = np.float32([[int(c[1]),int(c[0])] for c in y])

def return_no_shift():
    return np.zeros(2)
shift_dict = defaultdict(return_no_shift)
m = 10
n = 10
lx = goal_img.shape[1]/m
ly = goal_img.shape[0]/n
for k in range(len(goal_list)):
    p1 = goal_list[k]
    p2 = ori_list[k]
    ix = round(p1[0]/lx) 
    iy = round(p1[1]/ly) 
    shift_dict[(ix,iy)] = np.array([p2[0]-p1[0], p2[1]-p1[1]])

fig = plt.figure(figsize=(16,12))
plt.subplot(121)
plt.imshow(ori_img,cmap="gray")
# plt.axis("off")
plt.title("原始图像")
new_img = backward_trans(ori_img, m, n, shift_dict)
plt.subplot(122)
plt.imshow(new_img,cmap="gray")
plt.title("形变图像")
plt.show() 